from langchain_community.chat_models.yandex import (
    ChatYandexGPT,
)

__all__ = ["ChatYandexGPT"]
