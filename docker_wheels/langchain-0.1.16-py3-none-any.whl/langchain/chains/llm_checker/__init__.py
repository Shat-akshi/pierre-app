"""Chain that tries to verify assumptions before answering a question.

Heavily borrowed from https://github.com/jagilley/fact-checker
"""
