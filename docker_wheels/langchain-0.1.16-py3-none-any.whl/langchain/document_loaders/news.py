from langchain_community.document_loaders.news import NewsURLLoader

__all__ = ["NewsURLLoader"]
