from langchain_community.document_loaders.mediawikidump import MWDumpLoader

__all__ = ["MWDumpLoader"]
